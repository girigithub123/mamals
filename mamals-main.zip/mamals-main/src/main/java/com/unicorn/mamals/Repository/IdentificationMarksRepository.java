package com.unicorn.mamals.Repository;

import org.springframework.stereotype.Repository;

@Repository
public interface IdentificationMarksRepository {

}
