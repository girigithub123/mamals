package com.unicorn.mamals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MamalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
